var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/toolbar.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/convert.js":
/*!************************!*\
  !*** ./src/convert.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch/dom */ "sketch/dom");
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! sketch/ui */ "sketch/ui");
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sketch_ui__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./parse */ "./src/parse.js");
/* harmony import */ var _message__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./message */ "./src/message.js");




/* harmony default export */ __webpack_exports__["default"] = (function () {
  var document = sketch_dom__WEBPACK_IMPORTED_MODULE_0__["Document"].getSelectedDocument();
  var selection = document.selectedLayers;

  if (!selection || selection.isEmpty) {
    sketch_ui__WEBPACK_IMPORTED_MODULE_1___default.a.message('⚠🚫至少要选择一个图层！🚫');
    return;
  }

  _message__WEBPACK_IMPORTED_MODULE_3__["default"].content = '';
  var res = selection.layers.map(function (layer) {
    return Object(_parse__WEBPACK_IMPORTED_MODULE_2__["default"])(layer);
  }); // 存入粘贴板

  var pasteboard = NSPasteboard.generalPasteboard();
  pasteboard.clearContents();

  if (res.length > 1) {
    pasteboard.setString_forType(JSON.stringify(res), NSPasteboardTypeString);
  } else {
    pasteboard.setString_forType(JSON.stringify(res[0]), NSPasteboardTypeString);
  }

  var content = _message__WEBPACK_IMPORTED_MODULE_3__["default"].content || '🌈转换成功，数据已存入粘贴板！🌈';
  sketch_ui__WEBPACK_IMPORTED_MODULE_1___default.a.message(content);
  return res;
});

/***/ }),

/***/ "./src/message.js":
/*!************************!*\
  !*** ./src/message.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  content: ''
});

/***/ }),

/***/ "./src/parse.js":
/*!**********************!*\
  !*** ./src/parse.js ***!
  \**********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch/dom */ "sketch/dom");
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./util */ "./src/util.js");
/* harmony import */ var _type__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./type */ "./src/type.js");



var isNil = _util__WEBPACK_IMPORTED_MODULE_1__["default"].isNil;

function parse(layer, json, isChildren) {
  json = json || sketch_dom__WEBPACK_IMPORTED_MODULE_0___default.a.fromNative(layer); // console.log(layer);
  // console.log(json);

  var data = {
    tagName: ''
  };
  parseNormal(data, json, layer, isChildren);

  if (json.type === _type__WEBPACK_IMPORTED_MODULE_2__["default"].SHAPE_PATH) {
    parseShapePath(data, json, layer, isChildren);
  } else if (json.type === _type__WEBPACK_IMPORTED_MODULE_2__["default"].IMAGE) {
    parseImage(data, json, layer, isChildren);
  } else if (json.type === _type__WEBPACK_IMPORTED_MODULE_2__["default"].TEXT) {
    parseText(data, json, layer, isChildren);
  } else if (json.type === _type__WEBPACK_IMPORTED_MODULE_2__["default"].GROUP || json.type === _type__WEBPACK_IMPORTED_MODULE_2__["default"].SYMBOL_MASTER) {
    parseGroup(data, json, layer, isChildren);
  } else if (json.type === _type__WEBPACK_IMPORTED_MODULE_2__["default"].ARTBOARD) {
    parseArtboard(data, json, layer, isChildren);
  } else if (json.type === _type__WEBPACK_IMPORTED_MODULE_2__["default"].SYMBOL_INSTANCE) {
    parseSymbolInstance(data, json, layer, isChildren);
  }

  return data;
}

function parseNormal(data, json, layer, isChildren) {
  var style = json.style,
      transform = json.transform;
  ['id', 'name'].forEach(function (k) {
    data[k] = json[k];
  });
  data.props = {};
  data.props.style = {
    position: 'absolute'
  }; // 组里的元素相对父位置

  if (isChildren) {
    ['x', 'y'].forEach(function (k) {
      data.props.style[k] = json.frame[k];
    });
  }

  ['width', 'height'].forEach(function (k) {
    data.props.style[k] = json.frame[k];
  });

  if (!isNil(style.opacity) && style.opacity !== 1) {
    data.props.style.opacity = style.opacity;
  }

  if (transform.rotation) {
    data.props.style.rotateZ = transform.rotation;
  }

  if (transform.flippedHorizontally) {
    data.props.style.scaleX = -1;
  }

  if (transform.flippedVertically) {
    data.props.style.scaleY = -1;
  }

  return data;
}

function parseShapePath(data, json, layer) {
  data.tagName = '$polygon';
  var points = json.points,
      _json$style = json.style,
      fills = _json$style.fills,
      borders = _json$style.borders,
      borderOptions = _json$style.borderOptions; // 点和控制点

  var pts = [];
  var cts = []; // 是否都是直线

  var hasControl;
  points.forEach(function (item, index) {
    var point = item.point,
        curveFrom = item.curveFrom,
        pointType = item.pointType;
    var nextPoint = index === points.length - 1 ? points[0] : points[index + 1];
    var curveTo = nextPoint.curveTo,
        nextPointType = nextPoint.pointType;
    pts.push([point.x, point.y]);

    if (!json.closed && index === points.length - 1) {
      // polyline
      return;
    } // sketch导出的curveFrom和curveTo有问题，如果是straight，应该直接是point


    if (nextPointType === 'Straight') {
      curveTo = nextPoint.point;
    }

    if (pointType === 'Straight' && nextPointType === 'Straight') {
      cts.push(null);
    } else {
      cts.push([curveFrom.x, curveFrom.y, curveTo.x, curveTo.y]);
      hasControl = true;
    }
  });
  data.props.points = pts;

  if (hasControl) {
    data.props.controls = cts;
  } // 描绘属性，取第一个可用的，无法多个并存


  if (fills && fills.length) {
    var fill = _util__WEBPACK_IMPORTED_MODULE_1__["default"].getFillStyle(fills, json);

    if (fill) {
      data.props.style.fill = fill;
    }
  }

  if (borders && borders.length) {
    var borderStyle = _util__WEBPACK_IMPORTED_MODULE_1__["default"].getBorderStyle(borders, borderOptions);

    if (borderStyle) {
      data.props.style.strokeWidth = borderStyle.width;
      data.props.style.stroke = borderStyle.color;
      data.props.style.strokeDasharray = borderStyle.strokeDasharray;
      data.props.style.strokeLinecap = borderStyle.strokeLinecap;
    }
  } else {
    data.props.strokeWidth = 0;
  }

  return data;
}

function parseImage(data, json, layer) {
  data.tagName = 'img';
  var _json$style2 = json.style,
      borders = _json$style2.borders,
      borderOptions = _json$style2.borderOptions,
      exportFormats = json.exportFormats; // 以exportFormats第一项为导入的样式，默认为png;

  var fileFormat = _util__WEBPACK_IMPORTED_MODULE_1__["default"].getImageFormat(exportFormats);
  data.props.src = _util__WEBPACK_IMPORTED_MODULE_1__["default"].base64SrcEncodedFromNsData(layer.image.nsdata, fileFormat);
  var borderStyle = _util__WEBPACK_IMPORTED_MODULE_1__["default"].getBorderStyle(borders, borderOptions);

  if (borderStyle) {
    data.props.style.border = "".concat(borderStyle.width, "px ").concat(borderStyle.strokeDasharray ? 'dashed' : 'solid', " ").concat(borderStyle.color);
  }

  return data;
}

function parseText(data, json, layer) {
  data.tagName = 'span';
  ['fontSize', 'fontFamily'].forEach(function (k) {
    data.props.style[k] = json.style && json.style[k];
  });
  data.props.style.fontWeight = _util__WEBPACK_IMPORTED_MODULE_1__["default"].appKitWeightToCSSWeight(json.style.fontWeight);
  data.props.style.textAlign = json.style.alignment;
  data.props.style.color = json.style.textColor; // fillColor override

  var fillStyle = _util__WEBPACK_IMPORTED_MODULE_1__["default"].getFillStyle(json.style.fills);

  if (fillStyle && fillStyle.color) {
    data.props.style.color = fillStyle.color;
  } // 0 - variable width (fixed height)
  // 1 - variable height (fixed width)
  // 2 - fixed width and height


  var textBehaviour = layer.sketchObject.textBehaviour();

  if (textBehaviour === 0) {
    delete data.props.style.width;
  } else if (textBehaviour === 1) {
    delete data.props.style.height;
  }

  data.children = [json.text];
  return data;
}

function parseGroup(data, json, layer) {
  data.tagName = 'div';
  data.children = [];
  var document = sketch_dom__WEBPACK_IMPORTED_MODULE_0___default.a.getSelectedDocument(); // 递归每一层的layer

  for (var i = 0; i < json.layers.length; i++) {
    var layerJson = json.layers[i];

    var _layer = document.getLayerWithID(layerJson.id);

    var layerData = parse(_layer, layerJson, true);
    data.children.push(layerData);
  }

  return data;
}

function parseArtboard(data, json, layer) {
  data.tagName = 'div';
  data.children = [];
  var document = sketch_dom__WEBPACK_IMPORTED_MODULE_0___default.a.getSelectedDocument(); // 递归每一层的layer

  for (var i = 0; i < json.layers.length; i++) {
    var layerJson = json.layers[i];

    var _layer2 = document.getLayerWithID(layerJson.id);

    var layerData = convert(_layer2, layerJson);
    data.children.push(layerData);
  }

  if (json.background.enabled && json.background.color) {
    data.props.style.backgroundColor = json.background.color;
  }

  return data;
}

function parseSymbolInstance(data, json, layer) {}

/* harmony default export */ __webpack_exports__["default"] = (parse);

/***/ }),

/***/ "./src/toolbar.js":
/*!************************!*\
  !*** ./src/toolbar.js ***!
  \************************/
/*! exports provided: onRunToolBar */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onRunToolBar", function() { return onRunToolBar; });
/* harmony import */ var _convert__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./convert */ "./src/convert.js");

function onRunToolBar(context) {
  var pluginSketch = context.plugin.url().URLByAppendingPathComponent('Contents').URLByAppendingPathComponent('Resources');

  function getImage(name, size) {
    var imageURL = pluginSketch.URLByAppendingPathComponent(name + '.png');
    var image = NSImage.alloc().initWithContentsOfURL(imageURL);
    image.setSize(size);
    return image;
  }

  function addButton(rect, name, callAction) {
    var button = NSButton.alloc().initWithFrame(rect);
    var image = getImage(name, rect.size);
    button.setImage(image);
    button.setBordered(false);
    button.sizeToFit();
    button.setButtonType(NSMomentaryChangeButton);
    button.setCOSJSTargetFunction(callAction);
    button.setAction('callAction:');
    return button;
  }

  function addImage(rect, name) {
    var view = NSImageView.alloc().initWithFrame(rect);
    var image = getImage(name, rect.size);
    view.setImage(image);
    return view;
  }

  var toolbar = NSPanel.alloc().init();
  coscript.setShouldKeepAround(true); // toolbar.setStyleMask(NSTitledWindowMask + NSClosableWindowMask);

  toolbar.setStyleMask(NSTitledWindowMask + NSFullSizeContentViewWindowMask);
  toolbar.setBackgroundColor(NSColor.colorWithRed_green_blue_alpha(1, 1, 1, 1));
  toolbar.setTitleVisibility(NSWindowTitleHidden);
  toolbar.setTitlebarAppearsTransparent(true);
  toolbar.setFrame_display(NSMakeRect(100, 200, 120, 78), false);
  toolbar.becomeKeyWindow();
  toolbar.setLevel(NSFloatingWindowLevel);
  var contentView = toolbar.contentView();
  var iconView = addImage(NSMakeRect(10, 57, 16, 16), 'icon');
  contentView.addSubview(iconView);
  var lineView = addImage(NSMakeRect(8, 52, 104, 1), 'line');
  contentView.addSubview(lineView);
  var closeBtn = addButton(NSMakeRect(10, 18, 16, 16), 'close', function () {
    coscript.setShouldKeepAround(false);
    toolbar.close();
  });
  contentView.addSubview(closeBtn);
  var convertBtn = addButton(NSMakeRect(36, 10, 32, 32), 'convert', function () {
    Object(_convert__WEBPACK_IMPORTED_MODULE_0__["default"])();
  });
  contentView.addSubview(convertBtn);
  var link = addButton(NSMakeRect(78, 10, 32, 32), 'link', function () {
    console.log(22);
  });
  contentView.addSubview(link);
  toolbar.makeKeyAndOrderFront(nil);
}

/***/ }),

/***/ "./src/type.js":
/*!*********************!*\
  !*** ./src/type.js ***!
  \*********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  GROUP: 'Group',
  IMAGE: 'Image',
  TEXT: 'Text',
  SHAPE: 'Shape',
  SHAPE_PATH: 'ShapePath',
  ARTBOARD: 'Artboard',
  PAGE: 'Page',
  SYMBOL_INSTANCE: 'SymbolInstance',
  SYMBOL_MASTER: 'SymbolMaster',
  SLICE: 'Slice',
  HOT_SPOT: 'HotSpot'
});

/***/ }),

/***/ "./src/util.js":
/*!*********************!*\
  !*** ./src/util.js ***!
  \*********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _message__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./message */ "./src/message.js");

/* harmony default export */ __webpack_exports__["default"] = ({
  isNil: function isNil(v) {
    return v === undefined || v === null;
  },
  int2rgba: function int2rgba(color) {
    if (Array.isArray(color)) {
      if (color.length === 4) {
        return 'rgba(' + color.join(',') + ')';
      } else if (color.length === 3) {
        return 'rgba(' + color.join(',') + ',1)';
      }
    }

    return color || 'rgba(0,0,0,0)';
  },
  rgba2int: function rgba2int(color) {
    if (Array.isArray(color)) {
      return color;
    }

    var res = [];

    if (!color || color === 'transparent') {
      res = [0, 0, 0, 0];
    } else if (color.charAt(0) === '#') {
      color = color.slice(1);

      if (color.length === 3) {
        res.push(parseInt(color.charAt(0) + color.charAt(0), 16));
        res.push(parseInt(color.charAt(1) + color.charAt(1), 16));
        res.push(parseInt(color.charAt(2) + color.charAt(2), 16));
        res[3] = 1;
      } else if (color.length === 6) {
        res.push(parseInt(color.slice(0, 2), 16));
        res.push(parseInt(color.slice(2, 4), 16));
        res.push(parseInt(color.slice(4), 16));
        res[3] = 1;
      } else if (color.length === 8) {
        res.push(parseInt(color.slice(0, 2), 16));
        res.push(parseInt(color.slice(2, 4), 16));
        res.push(parseInt(color.slice(4, 6), 16));
        res.push(parseInt(color.slice(6), 16) / 255);
      } else {
        res[0] = res[1] = res[2] = 0;
        res[3] = 1;
      }
    } else {
      var c = color.match(/rgba?\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*([\d.]+))?\s*\)/i);

      if (c) {
        res = [parseInt(c[1]), parseInt(c[2]), parseInt(c[3])];

        if (!isNil(c[4])) {
          res[3] = parseFloat(c[4]);
        } else {
          res[3] = 1;
        }
      } else {
        res = [0, 0, 0, 0];
      }
    }

    return res;
  },
  getFillStyle: function getFillStyle(fills, json) {
    if (!fills || !fills.length) {
      return;
    }

    for (var i = 0; i < fills.length; i++) {
      var fill = fills[i];

      if (!fill.enabled) {
        continue;
      }

      if (fill.fillType === 'Color') {
        return fill.color;
      } else if (fill.fillType === 'Gradient') {
        console.log(fill);
        var _fill$gradient = fill.gradient,
            from = _fill$gradient.from,
            to = _fill$gradient.to,
            aspectRatio = _fill$gradient.aspectRatio,
            gradientType = _fill$gradient.gradientType,
            stops = _fill$gradient.stops;

        if (gradientType === 'Linear') {
          var s = "radialGradient(".concat(from.x, " ").concat(from.y, " ").concat(to.x, " ").concat(to.y);
          stops.forEach(function (item) {
            s += ", ".concat(item.color, " ").concat(item.position * 100, "%");
          });
          s += ')';
          return s;
        } else if (gradientType === 'Radial') {
          var _s = "radialGradient(".concat(from.x, " ").concat(from.y, " ").concat(to.x, " ").concat(to.y, " ").concat(aspectRatio || 1);

          stops.forEach(function (item) {
            _s += ", ".concat(item.color, " ").concat(item.position * 100, "%");
          });
          _s += ')';
          return _s;
        } else if (gradientType === 'Angular') {
          var _s2 = "conicGradient(";
          stops = stops.slice(0);

          var _i = stops.length - 1;

          if (stops[_i].position < 1) {
            stops.push({
              position: 1,
              color: stops[_i].color
            });
          }

          if (stops[0].position > 0) {
            stops.unshift({
              position: 0,
              color: stops[0].color
            });
          }

          stops.forEach(function (item, i) {
            if (i) {
              _s2 += ', ';
            }

            _s2 += "".concat(item.color, " ").concat(item.position * 100, "%");
          });
          _s2 += ')';
          return _s2;
        }
      } else {
        _message__WEBPACK_IMPORTED_MODULE_0__["default"].content = '⚠️暂不支持图案填充⚠️';
      }
    }
  },
  getBorderStyle: function getBorderStyle(borders, borderOptions) {
    if (!borders || !borders.length) {
      return;
    }

    for (var i = 0; i < borders.length; i++) {
      var border = borders[i];

      if (!border.enabled || border.thickness <= 0) {
        continue;
      }

      var res = {
        width: border.thickness
      };

      if (borderOptions.dashePattern && borderOptions.dashePattern.length) {
        res.strokeDasharray = borderOptions.dashePattern;
      }

      if ({
        Butt: 'butt',
        Round: 'round',
        Projecting: 'square'
      }.hasOwnProperty(borderOptions.lineEnd)) {
        res.strokeLinecap = borderOptions.lineEnd;
      }

      if (border.fillType === 'Color') {
        res.color = border.color;
      } else if (border.fillType === 'Gradient') {
        var _border$gradient = border.gradient,
            from = _border$gradient.from,
            to = _border$gradient.to,
            aspectRatio = _border$gradient.aspectRatio,
            gradientType = _border$gradient.gradientType,
            stops = _border$gradient.stops;

        if (gradientType === 'Linear') {
          var s = "radialGradient(".concat(from.x, " ").concat(from.y, " ").concat(to.x, " ").concat(to.y);
          stops.forEach(function (item) {
            s += ", ".concat(item.position * 100, "% ").concat(item.color);
          });
          s += ')';
          res.color = s;
        } else if (gradientType === 'Radial') {
          var _s3 = "radialGradient(".concat(from.x, " ").concat(from.y, " ").concat(to.x, " ").concat(to.y, " ").concat(aspectRatio || 1);

          stops.forEach(function (item) {
            _s3 += ", ".concat(item.position * 100, "% ").concat(item.color);
          });
          _s3 += ')';
          res.color = _s3;
        }
      }

      return res;
    }
  },
  getImageFormat: function getImageFormat(exportFormats) {
    var imageFormat = 'png';

    if (exportFormats && exportFormats.length) {
      exportFormats.some(function (exportFormat) {
        if (exportFormat && exportFormat.fileFormat) {
          imageFormat = exportFormat.fileFormat;
          return true;
        }

        return false;
      });
    }

    return imageFormat;
  },
  base64SrcEncodedFromNsData: function base64SrcEncodedFromNsData(nsdata, imageFormat) {
    return "data:image/".concat(imageFormat, ";base64,").concat(nsdata.base64EncodedStringWithOptions(0));
  },
  appKitWeightToCSSWeight: function appKitWeightToCSSWeight(appKitWeight) {
    return [100, 100, 100, 200, 300, 400, 500, 500, 600, 700, 800, 900, 900, 900, 900, 900][appKitWeight] || 500;
  }
});

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onRunToolBar'] = __skpm_run.bind(this, 'onRunToolBar');
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=toolbar.js.map